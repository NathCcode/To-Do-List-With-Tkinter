#imporoots tkinter
import tkinter as tk

#incorperating code from to do app
def main():
    todolist = 'TDL.txt'
    discription = 'DISC.txt'
#creates space for new window
    def clearWindow():
        root.destroy()
        
    #page 1/home window    
    def mainPage():
        
        global clear
        global add
        global check
        global delete
        global root
        
        todolist = 'TDL.txt'
    #create widget
        root = tk.Tk()
        root.title('To Do List')
        
        screen_width = (root.winfo_screenwidth())/2 - 200
        screen_height = (root.winfo_screenheight())/2 - 200
        root.geometry("+%d+%d" % (screen_width, screen_height))
    #centeralized

    #logo imports logo for app
        logo = tk.PhotoImage(file="App_logo.png")

        tk.Label(root, image=logo).pack(side = 'top' )


#keeps open untill closed window
#displays list if there is anything inside it
        global PrioritySort
        class PrioritySort:
            def __init__(self,file,disc):
                self.file = file
                self.disc = disc
                
            def sort(self):
                global list1, list2

#removes blank items
                
                class NoBlanks:
                    def __init__(self, item, file):
                        self.item = item
                        self.file = file
                        
#determines if item is blank
                    def RemoveBlanks(self):
                        for i in range(len(self.item)):
                            if self.item[i] == []:
                                del self.item[i]
                                open(self.file,'w').close()
                                with open(self.file,'a') as edit:
                                    for i in range (len(self.item)):
                                        x = self.item[i]
                                        x - ' '.join(self.item[i])
                                        edit.write(x)
                                        edit.write('\n')

                with open(self.file,'r') as read:
                    list1 = [line.strip().split() for line in read]#unsorted list
                    list2 = list1#sorted list
                    
                                                          
                with open(self.disc,'r') as read:
                    disc1 = [line.strip().split() for line in read]# unsorted description
                    disc2 = disc1#sorted description
                    
                NoBlanks(list1,todolist).RemoveBlanks()
                NoBlanks(disc1,discription).RemoveBlanks()    
#since we are using lists to create the buttons,
#we must get the button id in order
#to figure out the position of the
#button in the list
                
                def populate(frame):
                    
                    button_id = []
                        
                    
                    for i in range(len(list1)):
                        global listButton
                        
                        class disp:
                            def __init__(self,dsc,lst,title):
                                self.dsc = dsc
                                self.lst = lst
                                self.title = title
                                
                            def label(self):
                                
                                ttl = self.title[self.dsc]
                                dscF = self.lst[self.dsc]
                                discP = tk.Tk()
                                
                                screen_width = (discP.winfo_screenwidth())/2 - 200
                                screen_height = (discP.winfo_screenheight())/2 - 200
                                discP.geometry("+%d+%d" % (screen_width, screen_height))
                                
                                tk.Label(discP,text = ttl,
                                         bg = 'white',
                                         height = 2,
                                         width = 42,
                                         relief = 'ridge',
                                         wraplength = 200).pack()
                                
                                tk.Label(discP,text = dscF,
                                         bg = 'linen',
                                         height = 15,
                                         width = 42,
                                         relief = 'ridge',
                                         wraplength = 200).pack()
                                
                                discP.resizable(False,False)
                                discP.mainloop()
                    
                        global listButton
                        listButton = tk.Button(frame, text = list1[i], width = 49 , height = 2,
                                               relief = 'ridge',
                                               command = lambda i = i: disp(i,disc1,list1).label())
                        listButton.pack()

                        

#button command = when button i is clicked open label i
                        
                def onFrameConfigure(canvas):
#reset scroll region to encompas inside frame
                    canvas.configure(scrollregion = canvas.bbox('all'))

#a scrollable frame. This makes bigger lists easier to fit the screen
                global canvas
                global vsb
                
                canvas = tk.Canvas(root, borderwidth = 0,height = 200, width = 250, bg = 'linen')
                frame= tk.Frame(canvas, bg ='linen')
                vsb = tk.Scrollbar(root, orient = 'vertical', command = canvas.yview) 
                canvas.configure(yscrollcommand = vsb.set)
                
#pack scroll frames
               
                vsb.pack(side = 'right', fill='y')
                canvas.pack(side = 'top', fill = 'both', expand = False)
                canvas.create_window((4,4), window=frame, anchor = 'nw')

#allows scrollbar to work only in  
                frame.bind('<Configure>', lambda event, canvas = canvas: onFrameConfigure(canvas))
                populate(frame)
                

     
        add = tk.Button(root,text= 'Add item',fg= 'green1',width = 49, height = 2, command = lambda:open_aLP())
        add.pack(side = 'top' )            
                    
        
        display = PrioritySort(todolist,discription)
        display.sort()
        
        
        # Work on layout so scroll bar dose not drop to low
        delete = tk.Button(root,text= 'Delete item',fg= 'orange red',width = 49, height = 2, command = lambda: deleteItem())
        delete.pack(side = 'top')
        
        root.resizable(False,False)        
        root.mainloop()


    #add to list Page
    def addListPage():
        global master
        
        master = tk.Tk()
        
        screen_width = (master.winfo_screenwidth())/2 - 200
        screen_height = (master.winfo_screenheight())/2 - 200
        master.geometry("+%d+%d" % (screen_width, screen_height))
        
    #adds item infomation for to do list
        add = tk.Label(master,
                       text= 'Title:',
                       font= 'arial 10 bold').grid(row=0)
        
        add2 =tk.Label(master,
                       text='details:',
                       font='arial 10 bold').grid(row=1)
        
    #allows user input    
        answer = tk.Entry(master)
        answer2 = tk.Entry(master)
        
    #submits, and allows a readable code for python    
        submit = tk.Button(master,
                        text = 'sumbit',
                        fg = 'green2',
                        width = 42,
                        height = 2,
                        command = lambda:[saveInput(),closeWindow()])

    #layout of user input boxes
        answer.grid(row=0,
                    column=1,
                    ipadx = 90,
                    pady=5,
                    padx= 10)
        
        answer2.grid(row=1,
                     column = 1,
                     ipadx = 90,
                     ipady = 25,
                     pady=10)
        

        submit.grid(row=2,
                    column =1,
                    pady=10)
        
        def saveInput():
#takes user input
            a1 = str(answer.get())
            a2 = str(answer2.get())

    #saves values in a .txt file

            with open(todolist,'a') as edit:
                edit.write(a1)
                edit.write('\n')
                edit.close()
            
            with open(discription,'a') as edit:
                edit.write(a2)
                edit.write('\n')
                edit.close()
                
# I am going to be using somthing similar to the display list to delete items        
                
    def deleteItem():
        vsb.destroy()
        canvas.destroy()
        delete.destroy()
        
        class delTask:
            def __init__ (self,lst,dsc):
                self.lst = lst
                self.dsc = dsc
            
            def destroyITM(self):
                
                def unPopulate(frame):
                    check_id = []
                    
                    with open(self.lst,'r') as read:

                        list1 = [line.strip().split() for line in read]#unsorted list
                        list2 = list1#sorted list
                        
                                                              
                    with open(self.dsc,'r') as read:
                        disc1 = [line.strip().split() for line in read]# unsorted description
                        disc2 = disc1#sorted description
                        
                        allchecks = []
                        is_checked = []

                    
                    def boxstates():
                        finalValue = []
                        for x in is_checked:
                            finalValue.append(x.get())
                         

                        for i in range(len(list1)):
                            if finalValue[i] == 1:
                                del list1[i]
                                del disc2[i]
                                
                                open(todolist,'w').close()
                                with open(todolist,'a') as edit:
                                    for i in range (len(list1)):
                                            x = ' '.join(list1[i])
                                            edit.write(str(x))
                                            edit.write('\n')
                                
                                open(discription,'w').close()
                                with open(discription,'a') as edit:
                                    for i in range (len(list1)):
                                            x = ' '.join(disc1[i])
                                            edit.write(str(x))
                                            edit.write('\n')
                                
                            
                        delete.destroy()
                        canvas.destroy()
                        vsb.destroy()
                        clearWindow()
                        mainPage()
                            
                    for i in range(len(list1)):
                        is_checked.append(tk.IntVar())
                        
                    for x, y in zip(is_checked, list1):
                        checkList = tk.Checkbutton(frame,
                                                   text = y,
                                                   width = 49, height = 2,
                                                   variable = x,
                                                   onvalue = 1,
                                                   offvalue = 0,
                                                   justify = 'right',
                                                   relief = 'ridge').pack(side = 'top')
                        
                        

                    delete = tk.Button(root, text = 'delete item',
                                        fg = 'red',
                                        width = 49,
                                        height = 2,
                                        command = boxstates)
                    
                    delete.pack(side = 'top')

                    
                def onFrameConfig(canvas):                    
                    canvas.configure(scrollregion = canvas.bbox('all'))

#a scrollable frame. This makes bigger lists easier to fit the screen

                canvas = tk.Canvas(root, borderwidth = 0,height = 200, width = 250, bg = 'linen')
                frame= tk.Frame(canvas, bg ='linen')
                vsb = tk.Scrollbar(root, orient = 'vertical', command = canvas.yview) 
                canvas.configure(yscrollcommand = vsb.set)
                
#pack scroll frames
               
                vsb.pack(side = 'right', fill='y')
                canvas.pack(side = 'top', fill = 'both', expand = False)
                canvas.create_window((4,4), window=frame, anchor = 'nw')

#allows scrollbar to work only in  
                frame.bind('<Configure>', lambda event, canvas = canvas: onFrameConfig(canvas))
                unPopulate(frame)
                
        remove = delTask(todolist, discription).destroyITM()
        
        
    def closeWindow():
        
        master.destroy()
        mainPage()       
        master.resizable(False,False)
        master.mainloop()

    #makes all but home make visible
    def open_mP():
        closeWindow()
        mainPage()

    #makes all but add list visible
    def open_aLP():
        clearWindow()
        addListPage()

    mainPage()

    
main()

#banner


#formats window


